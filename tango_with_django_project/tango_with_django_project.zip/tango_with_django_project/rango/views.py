from django.http import HttpResponse
from django.shortcuts import render


def index(request): 
    context_dict = {'boldmessage': "Crunchy, creamy, cookie, candy, cupcake!",
                    'jackadded' : "Hello World!"}
    return render(request, 'rango/index.html', context=context_dict)
    

def about(request): 
    return HttpResponse("Jack says: you are at the about page!")
